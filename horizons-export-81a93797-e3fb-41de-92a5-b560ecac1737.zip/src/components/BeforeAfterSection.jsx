
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Check, TrendingDown, TrendingUp } from 'lucide-react';

const BeforeAfterSection = () => {
  const [activeView, setActiveView] = useState('after');

  const beforeItems = [
    { icon: X, text: 'Website not loading', color: 'text-red-600' },
    { icon: X, text: 'Outdated design from 2010', color: 'text-red-600' },
    { icon: X, text: 'Not mobile-friendly', color: 'text-red-600' },
    { icon: X, text: 'No online ordering', color: 'text-red-600' },
    { icon: X, text: 'Using Gmail for business', color: 'text-red-600' },
    { icon: TrendingDown, text: 'Losing revenue daily', color: 'text-red-600' }
  ];

  const afterItems = [
    { icon: Check, text: 'Lightning-fast loading', color: 'text-green-600' },
    { icon: Check, text: 'Modern, professional design', color: 'text-green-600' },
    { icon: Check, text: 'Perfect on all devices', color: 'text-green-600' },
    { icon: Check, text: 'Direct online ordering', color: 'text-green-600' },
    { icon: Check, text: 'Professional @2doorsdown.com email', color: 'text-green-600' },
    { icon: TrendingUp, text: 'Increased revenue by 40%+', color: 'text-green-600' }
  ];

  return (
    <section id="before-after" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-[#F5F5DC] to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2C2C] mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            The Transformation
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto mb-8">
            See the difference a modern website makes
          </p>

          {/* Toggle Buttons */}
          <div className="inline-flex gap-2 bg-gray-200 p-2 rounded-lg">
            <button
              onClick={() => setActiveView('before')}
              className={`px-6 py-3 rounded-lg transition-all duration-300 font-semibold ${
                activeView === 'before'
                  ? 'bg-red-600 text-white shadow-lg'
                  : 'bg-transparent text-gray-700 hover:bg-gray-300'
              }`}
            >
              Current Situation
            </button>
            <button
              onClick={() => setActiveView('after')}
              className={`px-6 py-3 rounded-lg transition-all duration-300 font-semibold ${
                activeView === 'after'
                  ? 'bg-[#28A745] text-white shadow-lg'
                  : 'bg-transparent text-gray-700 hover:bg-gray-300'
              }`}
            >
              Your New Website
            </button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Before View */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{
              opacity: activeView === 'before' ? 1 : 0.3,
              scale: activeView === 'before' ? 1 : 0.95,
              x: 0
            }}
            transition={{ duration: 0.5 }}
            className={`bg-gradient-to-br from-red-50 to-red-100 rounded-xl p-8 shadow-lg border-2 ${
              activeView === 'before' ? 'border-red-600' : 'border-gray-300'
            }`}
          >
            <h3 className="text-3xl font-bold text-red-800 mb-6 flex items-center gap-3">
              <X className="w-8 h-8" />
              Current Situation
            </h3>
            <div className="space-y-6">
              {beforeItems.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="flex items-center gap-4 bg-white rounded-lg p-4 shadow-sm"
                >
                  <item.icon className={`w-8 h-8 ${item.color} flex-shrink-0`} />
                  <span className="text-lg text-gray-800">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* After View */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{
              opacity: activeView === 'after' ? 1 : 0.3,
              scale: activeView === 'after' ? 1 : 0.95,
              x: 0
            }}
            transition={{ duration: 0.5 }}
            className={`bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-8 shadow-lg border-2 ${
              activeView === 'after' ? 'border-green-600' : 'border-gray-300'
            }`}
          >
            <h3 className="text-3xl font-bold text-green-800 mb-6 flex items-center gap-3">
              <Check className="w-8 h-8" />
              Your New Website
            </h3>
            <div className="space-y-6">
              {afterItems.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="flex items-center gap-4 bg-white rounded-lg p-4 shadow-sm"
                >
                  <item.icon className={`w-8 h-8 ${item.color} flex-shrink-0`} />
                  <span className="text-lg text-gray-800">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default BeforeAfterSection;
