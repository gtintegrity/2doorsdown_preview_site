
import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, ShoppingCart, Mail } from 'lucide-react';

const ProblemSection = () => {
  const problems = [
    {
      icon: AlertCircle,
      title: 'Website Not Loading',
      description: 'Your current website is down, driving customers away and costing you sales every single day.'
    },
    {
      icon: ShoppingCart,
      title: 'No Online Ordering',
      description: 'Without online ordering, you\'re paying 30% fees to third-party apps and losing direct customer relationships.'
    },
    {
      icon: Mail,
      title: 'Unprofessional Email',
      description: 'Using Gmail or Yahoo emails makes your business look amateur and untrustworthy to potential customers.'
    }
  ];

  return (
    <section id="problem" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-[#2C2C2C] to-[#1a1a1a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            These Problems Are Costing You Money
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Every day without a working website means lost customers and revenue
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {problems.map((problem, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-t-4 border-[#8B0000]"
            >
              <problem.icon className="w-16 h-16 text-[#8B0000] mb-6" />
              <h3 className="text-2xl font-bold text-[#2C2C2C] mb-4" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                {problem.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {problem.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
