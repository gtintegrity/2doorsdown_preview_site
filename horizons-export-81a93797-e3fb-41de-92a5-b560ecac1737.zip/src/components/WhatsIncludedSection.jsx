
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const WhatsIncludedSection = () => {
  const features = [
    'Complete Website Rebuild',
    'Online Ordering System',
    'Professional Email Setup (@2doorsdown.com)',
    'Mobile-Responsive Design',
    'Easy Menu Management',
    'Daily Specials Section',
    'Customer Testimonials',
    'Photo Gallery',
    'Contact Form',
    'Google Maps Integration',
    'Social Media Links',
    'SEO Optimization',
    'SSL Security Certificate',
    '3 Weeks of Support',
    'Staff Training Session'
  ];

  const timeline = [
    {
      week: 'Week 1',
      title: 'Planning & Setup',
      tasks: ['Design mockups', 'Content collection', 'Professional email setup', 'Initial review']
    },
    {
      week: 'Week 2-3',
      title: 'Development',
      tasks: ['Website build', 'Online ordering setup', 'Menu configuration', 'Testing & refinement']
    },
    {
      week: 'Week 4',
      title: 'Launch',
      tasks: ['Final review', 'Staff training', 'Website launch', 'Ongoing support']
    }
  ];

  return (
    <section id="included" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-white to-[#F5F5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2C2C] mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            What's Included
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Everything you need to succeed online, delivered in 4 weeks
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Features Checklist */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-[#8B0000] mb-6" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Complete Package Features
              </h3>
              <div className="grid grid-cols-1 gap-4">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                    className="flex items-center gap-3"
                  >
                    <div className="bg-[#28A745] rounded-full p-1 flex-shrink-0">
                      <Check className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-gray-700 text-lg">{feature}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Timeline */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-[#8B0000] mb-6" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                4-Week Timeline
              </h3>
              <div className="relative">
                {/* Timeline Line */}
                <div className="absolute left-6 top-0 bottom-0 w-1 bg-[#8B0000]"></div>

                <div className="space-y-8">
                  {timeline.map((phase, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4, delay: index * 0.2 }}
                      className="relative pl-16"
                    >
                      {/* Timeline Dot */}
                      <div className="absolute left-3 top-0 w-7 h-7 bg-[#8B0000] rounded-full border-4 border-white shadow-lg"></div>

                      <div className="bg-[#F5F5DC] rounded-lg p-6">
                        <div className="text-sm font-bold text-[#8B0000] mb-1">{phase.week}</div>
                        <h4 className="text-xl font-bold text-[#2C2C2C] mb-3">{phase.title}</h4>
                        <ul className="space-y-2">
                          {phase.tasks.map((task, taskIndex) => (
                            <li key={taskIndex} className="flex items-center gap-2 text-gray-700">
                              <div className="w-1.5 h-1.5 bg-[#8B0000] rounded-full"></div>
                              {task}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhatsIncludedSection;
