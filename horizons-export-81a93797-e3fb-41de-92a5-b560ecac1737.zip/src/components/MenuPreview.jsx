
import React from 'react';
import { motion } from 'framer-motion';

const MenuPreview = () => {
  const menuCategories = [
    {
      category: 'Appetizers',
      items: [
        { name: 'Buffalo Wings', description: 'Crispy wings with your choice of sauce', price: 11.99 },
        { name: 'Loaded Nachos', description: 'Tortilla chips with cheese, jalapeños, sour cream', price: 9.99 },
        { name: 'Mozzarella Sticks', description: 'Golden fried with marinara sauce', price: 8.99 }
      ]
    },
    {
      category: 'Burgers & Sandwiches',
      items: [
        { name: 'Classic Cheeseburger', description: 'Angus beef with cheddar and special sauce', price: 12.99 },
        { name: 'BBQ Bacon Burger', description: 'Double patty with bacon and BBQ sauce', price: 15.99 },
        { name: 'Pulled Pork Sandwich', description: 'Slow-roasted pork with coleslaw', price: 13.99 },
        { name: 'Grilled Chicken Club', description: 'Grilled chicken, bacon, lettuce, tomato', price: 12.99 }
      ]
    },
    {
      category: 'Entrees',
      items: [
        { name: 'BBQ Ribs', description: 'Full rack with signature BBQ sauce', price: 24.99 },
        { name: 'Fish & Chips', description: 'Beer-battered cod with fries', price: 16.99 },
        { name: 'Grilled Salmon', description: 'Fresh Atlantic salmon with vegetables', price: 22.99 },
        { name: 'Sirloin Steak', description: '10oz sirloin with choice of sides', price: 26.99 }
      ]
    }
  ];

  return (
    <section id="menu" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-white to-[#F5F5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2C2C] mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Sample Menu
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Here's how your menu could look on your new website
          </p>
        </motion.div>

        <div className="space-y-12">
          {menuCategories.map((category, catIndex) => (
            <motion.div
              key={catIndex}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: catIndex * 0.2 }}
              className="bg-white rounded-xl shadow-lg p-8"
            >
              <h3
                className="text-3xl font-bold text-[#8B0000] mb-6 pb-4 border-b-2 border-[#8B0000]"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                {category.category}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {category.items.map((item, itemIndex) => (
                  <motion.div
                    key={itemIndex}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: itemIndex * 0.1 }}
                    className="flex justify-between items-start gap-4 p-4 rounded-lg hover:bg-[#F5F5DC] transition-all duration-300"
                  >
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-[#2C2C2C] mb-2">{item.name}</h4>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                    <span className="text-2xl font-bold text-[#8B0000] whitespace-nowrap">
                      ${item.price.toFixed(2)}
                    </span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mt-12"
        >
          <button className="bg-[#8B0000] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#6B0000] transition-all duration-300 transform hover:scale-105 shadow-lg">
            See Full Menu
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default MenuPreview;
