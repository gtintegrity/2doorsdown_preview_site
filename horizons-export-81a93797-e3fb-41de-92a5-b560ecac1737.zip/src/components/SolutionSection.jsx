
import React from 'react';
import { motion } from 'framer-motion';
import { Zap, ShoppingBag, Mail, Edit, Star, Image } from 'lucide-react';

const SolutionSection = () => {
  const features = [
    {
      icon: Zap,
      title: 'Fast Modern Website',
      description: 'Lightning-fast, mobile-responsive website that loads in under 2 seconds and looks amazing on all devices.'
    },
    {
      icon: ShoppingBag,
      title: 'Online Ordering System',
      description: 'Accept orders directly through your website without paying 30% fees to third-party apps.'
    },
    {
      icon: Mail,
      title: 'Professional Email',
      description: 'Custom @2doorsdown.com email addresses that build trust and credibility with customers.'
    },
    {
      icon: Edit,
      title: 'Easy Menu Management',
      description: 'Update your menu, prices, and daily specials anytime without needing a developer.'
    },
    {
      icon: Star,
      title: 'Customer Reviews',
      description: 'Showcase 5-star reviews and build social proof to attract more diners to your restaurant.'
    },
    {
      icon: Image,
      title: 'Photo Gallery',
      description: 'Beautiful gallery to showcase your delicious dishes and inviting atmosphere.'
    }
  ];

  return (
    <section id="solution" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-[#F5F5DC] to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2C2C] mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Everything You Need in One Package
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            A complete solution to grow your restaurant business online
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5, boxShadow: '0 20px 40px rgba(0,0,0,0.15)' }}
              className="bg-[#F5F5DC] rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300"
            >
              <feature.icon className="w-14 h-14 text-[#8B0000] mb-6" />
              <h3 className="text-2xl font-bold text-[#8B0000] mb-4" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                {feature.title}
              </h3>
              <p className="text-[#2C2C2C] leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SolutionSection;
