
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus, Trash2, ShoppingCart, X } from 'lucide-react';

const OnlineOrderingDemo = () => {
  const menuItems = [
    {
      id: 1,
      category: 'Burgers & Sandwiches',
      name: 'Classic Cheeseburger',
      description: 'Angus beef patty with cheddar, lettuce, tomato, and special sauce',
      price: 12.99,
      image: 'https://images.unsplash.com/photo-1681821674870-b958a37f8586'
    },
    {
      id: 2,
      category: 'Burgers & Sandwiches',
      name: 'BBQ Bacon Burger',
      description: 'Double patty with bacon, BBQ sauce, onion rings, and cheddar',
      price: 15.99,
      image: 'https://images.unsplash.com/photo-1700835880328-69e43e906677'
    },
    {
      id: 3,
      category: 'Burgers & Sandwiches',
      name: 'Pulled Pork Sandwich',
      description: 'Slow-roasted pulled pork with coleslaw on brioche bun',
      price: 13.99,
      image: 'https://images.unsplash.com/photo-1680287370324-8ba1fd88a066'
    },
    {
      id: 4,
      category: 'Entrees',
      name: 'Fish & Chips',
      description: 'Beer-battered cod with fries and tartar sauce',
      price: 16.99,
      image: 'https://images.unsplash.com/photo-1614103862009-d13eff600b53'
    },
    {
      id: 5,
      category: 'Entrees',
      name: 'BBQ Ribs',
      description: 'Full rack of slow-cooked ribs with signature BBQ sauce',
      price: 24.99,
      image: 'https://images.unsplash.com/photo-1656266979370-757a7b773a6a'
    },
    {
      id: 6,
      category: 'Appetizers',
      name: 'Buffalo Wings',
      description: 'Crispy chicken wings tossed in buffalo sauce',
      price: 11.99,
      image: 'https://images.unsplash.com/photo-1585684776438-e3dc810ff034'
    }
  ];

  const categories = ['All', 'Appetizers', 'Burgers & Sandwiches', 'Entrees', 'Sides', 'Desserts', 'Drinks'];

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState([]);
  const [deliveryMethod, setDeliveryMethod] = useState('pickup');

  const addToCart = (item) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    if (existingItem) {
      setCart(cart.map(cartItem =>
        cartItem.id === item.id
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const updateQuantity = (id, change) => {
    setCart(cart.map(item =>
      item.id === id
        ? { ...item, quantity: Math.max(0, item.quantity + change) }
        : item
    ).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const filteredItems = selectedCategory === 'All'
    ? menuItems
    : menuItems.filter(item => item.category === selectedCategory);

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.07;
  const deliveryFee = deliveryMethod === 'delivery' ? 4.99 : 0;
  const total = subtotal + tax + deliveryFee;

  return (
    <section id="ordering" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-[#F5F5DC] to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2C2C] mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Try the Online Ordering System
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Experience how easy it is for your customers to order directly from your website
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Categories Sidebar */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl p-6 shadow-lg sticky top-24">
              <h3 className="text-xl font-bold text-[#2C2C2C] mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-all duration-300 ${
                      selectedCategory === category
                        ? 'bg-[#8B0000] text-white font-semibold'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="lg:col-span-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <h4 className="text-xl font-bold text-[#2C2C2C] mb-2">{item.name}</h4>
                    <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold text-[#8B0000]">${item.price.toFixed(2)}</span>
                      <button
                        onClick={() => addToCart(item)}
                        className="bg-[#8B0000] text-white px-4 py-2 rounded-lg hover:bg-[#6B0000] transition-all duration-300 flex items-center gap-2"
                      >
                        <Plus className="w-4 h-4" />
                        Add
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Shopping Cart */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl p-6 shadow-lg sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-[#2C2C2C] flex items-center gap-2">
                  <ShoppingCart className="w-6 h-6" />
                  Your Order
                </h3>
                <span className="bg-[#8B0000] text-white px-3 py-1 rounded-full text-sm font-bold">
                  {cart.reduce((sum, item) => sum + item.quantity, 0)}
                </span>
              </div>

              {/* Delivery Method Toggle */}
              <div className="mb-6">
                <div className="flex gap-2 bg-gray-100 p-1 rounded-lg">
                  <button
                    onClick={() => setDeliveryMethod('pickup')}
                    className={`flex-1 py-2 px-4 rounded-lg transition-all duration-300 ${
                      deliveryMethod === 'pickup'
                        ? 'bg-white shadow-md font-semibold'
                        : 'text-gray-600'
                    }`}
                  >
                    Pickup
                  </button>
                  <button
                    onClick={() => setDeliveryMethod('delivery')}
                    className={`flex-1 py-2 px-4 rounded-lg transition-all duration-300 ${
                      deliveryMethod === 'delivery'
                        ? 'bg-white shadow-md font-semibold'
                        : 'text-gray-600'
                    }`}
                  >
                    Delivery
                  </button>
                </div>
              </div>

              {/* Cart Items */}
              <div className="space-y-4 mb-6 max-h-[400px] overflow-y-auto">
                {cart.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    Your cart is empty
                  </div>
                ) : (
                  cart.map((item) => (
                    <div key={item.id} className="border-b border-gray-200 pb-4">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-semibold text-[#2C2C2C]">{item.name}</span>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(item.id, -1)}
                            className="bg-gray-200 p-1 rounded hover:bg-gray-300"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="font-semibold w-8 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, 1)}
                            className="bg-gray-200 p-1 rounded hover:bg-gray-300"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        <span className="font-bold text-[#8B0000]">
                          ${(item.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Totals */}
              {cart.length > 0 && (
                <div className="border-t-2 border-gray-200 pt-4 space-y-2">
                  <div className="flex justify-between text-gray-700">
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-700">
                    <span>Tax (7%)</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  {deliveryMethod === 'delivery' && (
                    <div className="flex justify-between text-gray-700">
                      <span>Delivery Fee</span>
                      <span>${deliveryFee.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xl font-bold text-[#2C2C2C] pt-2 border-t-2 border-gray-200">
                    <span>Total</span>
                    <span className="text-[#8B0000]">${total.toFixed(2)}</span>
                  </div>
                  <button className="w-full bg-[#28A745] text-white py-3 rounded-lg font-bold hover:bg-[#20893a] transition-all duration-300 mt-4">
                    Checkout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OnlineOrderingDemo;
