
import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const TestimonialsSection = () => {
  const testimonials = [
    {
      quote: "Online ordering increased our revenue by 40% in the first month! Our customers love the convenience, and we're saving thousands on third-party app fees.",
      author: "Sarah Mitchell",
      restaurant: "The Cozy Corner Bistro",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    {
      quote: "Best investment we made for our restaurant. Customers love the convenience and the professional look has brought in so many new diners. Couldn't be happier!",
      author: "Michael Chen",
      restaurant: "Dragon Garden Restaurant",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop"
    }
  ];

  return (
    <section id="testimonials" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-[#F5F5DC] to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2C2C] mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            What Restaurant Owners Say
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Real results from real restaurants
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-white rounded-xl shadow-lg p-8 border-l-4 border-[#8B0000] hover:shadow-2xl transition-all duration-300"
            >
              <Quote className="w-12 h-12 text-[#8B0000] opacity-50 mb-4" />
              
              <p className="text-lg text-gray-700 italic mb-6 leading-relaxed">
                "{testimonial.quote}"
              </p>

              <div className="flex items-center gap-4 mb-4">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.author}
                  className="w-16 h-16 rounded-full object-cover border-2 border-[#8B0000]"
                />
                <div>
                  <div className="font-bold text-[#2C2C2C] text-lg">{testimonial.author}</div>
                  <div className="text-gray-600">{testimonial.restaurant}</div>
                </div>
              </div>

              <div className="flex gap-1">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-[#FFD700] text-[#FFD700]" />
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
