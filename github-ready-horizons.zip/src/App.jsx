
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronUp } from 'lucide-react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import ProblemSection from '@/components/ProblemSection';
import SolutionSection from '@/components/SolutionSection';
import ROICalculator from '@/components/ROICalculator';
import OnlineOrderingDemo from '@/components/OnlineOrderingDemo';
import WhatsIncludedSection from '@/components/WhatsIncludedSection';
import BeforeAfterSection from '@/components/BeforeAfterSection';
import MenuPreview from '@/components/MenuPreview';
import TestimonialsSection from '@/components/TestimonialsSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';
import { Toaster } from '@/components/ui/toaster';

function App() {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>2 Doors Down - Modern Website Proposal | Online Ordering & Professional Email</title>
        <meta
          name="description"
          content="Transform your restaurant with a modern website, online ordering system, and professional email for just $2,497. See how we can increase your revenue by 40%."
        />
      </Helmet>

      <div className="min-h-screen">
        <Header />
        <Hero />
        <ProblemSection />
        <SolutionSection />
        <ROICalculator />
        <OnlineOrderingDemo />
        <WhatsIncludedSection />
        <BeforeAfterSection />
        <MenuPreview />
        <TestimonialsSection />
        <ContactSection />
        <Footer />

        {/* Back to Top Button */}
        <AnimatePresence>
          {showBackToTop && (
            <motion.button
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              onClick={scrollToTop}
              className="fixed bottom-8 right-8 bg-[#8B0000] text-white p-4 rounded-full shadow-lg hover:bg-[#6B0000] transition-all duration-300 z-50 group"
            >
              <ChevronUp className="w-6 h-6 group-hover:transform group-hover:-translate-y-1 transition-transform" />
            </motion.button>
          )}
        </AnimatePresence>

        <Toaster />
      </div>
    </>
  );
}

export default App;
