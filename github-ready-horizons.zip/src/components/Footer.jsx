
import React from 'react';
import { Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#2C2C2C] text-[#F5F5DC] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Disclaimer */}
        <div className="text-center mb-8 pb-8 border-b border-gray-600">
          <p className="text-lg font-semibold mb-2">
            This is a website proposal demonstration
          </p>
          <p className="text-sm text-gray-400">
            Website Proposal by Your Agency
          </p>
        </div>

        {/* Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">2 Doors Down</h3>
            <div className="space-y-2 text-sm">
              <p>123 Main Street</p>
              <p>Cheyenne, WY 82001</p>
              <p>(307) 634-6008</p>
              <p>info@2doorsdown.com</p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Quick Links</h3>
            <div className="space-y-2 text-sm">
              <p className="hover:text-white transition-colors cursor-pointer">About Us</p>
              <p className="hover:text-white transition-colors cursor-pointer">Menu</p>
              <p className="hover:text-white transition-colors cursor-pointer">Order Online</p>
              <p className="hover:text-white transition-colors cursor-pointer">Contact</p>
            </div>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Follow Us</h3>
            <div className="flex gap-4">
              <a
                href="#"
                className="bg-[#8B0000] p-3 rounded-full hover:bg-[#6B0000] transition-all duration-300"
              >
                <Facebook className="w-5 h-5 text-white" />
              </a>
              <a
                href="#"
                className="bg-[#8B0000] p-3 rounded-full hover:bg-[#6B0000] transition-all duration-300"
              >
                <Instagram className="w-5 h-5 text-white" />
              </a>
              <a
                href="#"
                className="bg-[#8B0000] p-3 rounded-full hover:bg-[#6B0000] transition-all duration-300"
              >
                <Twitter className="w-5 h-5 text-white" />
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center text-sm text-gray-400 pt-8 border-t border-gray-600">
          <p>&copy; 2026 2 Doors Down. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
