
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, DollarSign } from 'lucide-react';

const ROICalculator = () => {
  const [animatedValues, setAnimatedValues] = useState({
    monthlyGain: 0,
    annualGain: 0,
    payback: 0
  });

  useEffect(() => {
    const targetValues = {
      monthlyGain: 1491,
      annualGain: 17892,
      payback: 1.7
    };

    const duration = 2000;
    const steps = 60;
    const stepDuration = duration / steps;

    let currentStep = 0;

    const interval = setInterval(() => {
      currentStep++;
      const progress = currentStep / steps;

      setAnimatedValues({
        monthlyGain: Math.floor(targetValues.monthlyGain * progress),
        annualGain: Math.floor(targetValues.annualGain * progress),
        payback: (targetValues.payback * progress).toFixed(1)
      });

      if (currentStep >= steps) {
        clearInterval(interval);
        setAnimatedValues(targetValues);
      }
    }, stepDuration);

    return () => clearInterval(interval);
  }, []);

  return (
    <section id="roi" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-b from-white to-[#F5F5DC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2C2C] mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            See Your Return on Investment
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Based on real restaurant data - see how much you could save and earn
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Current State */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-red-50 border-2 border-red-200 rounded-xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-bold text-red-800 mb-6" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Current Situation (DoorDash)
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Monthly Orders:</span>
                <span className="text-xl font-bold text-gray-900">50</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Average Order:</span>
                <span className="text-xl font-bold text-gray-900">$35</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Gross Revenue:</span>
                <span className="text-xl font-bold text-gray-900">$1,750</span>
              </div>
              <div className="flex justify-between items-center border-t-2 border-red-300 pt-4">
                <span className="text-gray-700">Platform Fees (30%):</span>
                <span className="text-xl font-bold text-red-600">-$525</span>
              </div>
              <div className="flex justify-between items-center bg-red-100 p-4 rounded-lg">
                <span className="text-lg font-semibold text-gray-900">Net Revenue:</span>
                <span className="text-2xl font-bold text-red-800">$1,225</span>
              </div>
            </div>
          </motion.div>

          {/* New Website */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-green-50 border-2 border-[#28A745] rounded-xl p-8 shadow-lg"
          >
            <h3 className="text-2xl font-bold text-[#28A745] mb-6" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              With Your New Website
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Monthly Orders:</span>
                <span className="text-xl font-bold text-gray-900">80 (+60%)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Average Order:</span>
                <span className="text-xl font-bold text-gray-900">$35</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Gross Revenue:</span>
                <span className="text-xl font-bold text-gray-900">$2,800</span>
              </div>
              <div className="flex justify-between items-center border-t-2 border-green-300 pt-4">
                <span className="text-gray-700">Processing Fees (3%):</span>
                <span className="text-xl font-bold text-green-600">-$84</span>
              </div>
              <div className="flex justify-between items-center bg-green-100 p-4 rounded-lg">
                <span className="text-lg font-semibold text-gray-900">Net Revenue:</span>
                <span className="text-2xl font-bold text-[#28A745]">$2,716</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Results */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="bg-gradient-to-r from-[#28A745] to-[#20893a] rounded-xl p-8 shadow-2xl text-white"
        >
          <div className="flex items-center justify-center mb-6">
            <TrendingUp className="w-12 h-12 mr-4" />
            <h3 className="text-3xl font-bold" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Your Financial Impact
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <DollarSign className="w-8 h-8 mx-auto mb-2" />
              <div className="text-5xl font-bold mb-2">+${animatedValues.monthlyGain.toLocaleString()}</div>
              <div className="text-xl opacity-90">Monthly Increase</div>
            </div>
            <div className="text-center">
              <DollarSign className="w-8 h-8 mx-auto mb-2" />
              <div className="text-5xl font-bold mb-2">+${animatedValues.annualGain.toLocaleString()}</div>
              <div className="text-xl opacity-90">Annual Increase</div>
            </div>
            <div className="text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2" />
              <div className="text-5xl font-bold mb-2">{animatedValues.payback} mo</div>
              <div className="text-xl opacity-90">Payback Period</div>
            </div>
          </div>

          <div className="mt-8 text-center text-lg opacity-90">
            Investment of $2,497 pays for itself in less than 2 months!
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ROICalculator;
