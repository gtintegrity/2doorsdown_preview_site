
import React, { useState, useEffect } from 'react';
import { Phone, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { label: 'About', href: 'hero' },
    { label: 'Features', href: 'solution' },
    { label: 'Pricing', href: 'roi' },
    { label: 'Contact', href: 'contact' }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-[#8B0000] shadow-lg' : 'bg-[#8B0000]/95'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-2xl font-bold text-white cursor-pointer"
            onClick={() => scrollToSection('hero')}
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            2 Doors Down
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link, index) => (
              <motion.button
                key={link.href}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => scrollToSection(link.href)}
                className="text-white hover:text-[#F5F5DC] transition-colors duration-300 font-medium"
              >
                {link.label}
              </motion.button>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            <a
              href="tel:3076346008"
              className="flex items-center gap-2 text-white hover:text-[#F5F5DC] transition-colors duration-300"
            >
              <Phone className="w-5 h-5" />
              <span className="font-medium">(307) 634-6008</span>
            </a>
            <button
              onClick={() => scrollToSection('contact')}
              className="bg-white text-[#8B0000] px-6 py-3 rounded-lg font-semibold hover:bg-[#F5F5DC] transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Schedule Free Consultation
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden text-white p-2"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden overflow-hidden"
            >
              <nav className="py-4 space-y-4">
                {navLinks.map((link) => (
                  <button
                    key={link.href}
                    onClick={() => scrollToSection(link.href)}
                    className="block w-full text-left text-white hover:text-[#F5F5DC] transition-colors duration-300 font-medium py-2"
                  >
                    {link.label}
                  </button>
                ))}
                <a
                  href="tel:3076346008"
                  className="flex items-center gap-2 text-white hover:text-[#F5F5DC] transition-colors duration-300 py-2"
                >
                  <Phone className="w-5 h-5" />
                  <span className="font-medium">(307) 634-6008</span>
                </a>
                <button
                  onClick={() => scrollToSection('contact')}
                  className="w-full bg-white text-[#8B0000] px-6 py-3 rounded-lg font-semibold hover:bg-[#F5F5DC] transition-all duration-300"
                >
                  Schedule Free Consultation
                </button>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Demo Badge */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5 }}
        className="fixed top-24 right-4 bg-[#28A745] text-white px-4 py-2 rounded-full shadow-lg font-bold text-sm z-50"
      >
        DEMO PROPOSAL
      </motion.div>
    </header>
  );
};

export default Header;
